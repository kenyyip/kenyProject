package com.keny.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Zip {

	public static void main(String[] args) {
		// Zip.ZipMultiFile("E:/logs", "c:/abc.zip");
		List<String> list = new ArrayList<String>();
		list.add("E:/logs/a.txt");
		list.add("E:/logs/b.txt");
		list.add("E:/logs/c.txt");
		list.add("E:/logs/d.txt");
		Zip.ZipMultiFile(list, "c:/abc.zip");
	}

	/**
	 * 一次性压缩多个文件，文件存放至一个文件夹中
	 * 
	 * @param filepath
	 *            文件目录路径
	 * @param zippath
	 *            zip包路径
	 */
	public static void ZipMultiFile(String filepath, String zippath) {
		try {
			// 被压缩的文件夹
			File file = new File(filepath);
			// 压缩后的ZIP包
			File zipFile = new File(zippath);
			InputStream input = null;
			ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFile));
			if (file.isDirectory()) {
				File[] files = file.listFiles();
				for (int i = 0; i < files.length; ++i) {
					input = new FileInputStream(files[i]);
					zipOut.putNextEntry(new ZipEntry(files[i].getName()));
					int temp = 0;
					while ((temp = input.read()) != -1) {
						zipOut.write(temp);
					}
					input.close();
				}
			}
			zipOut.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 压缩多个文件
	 * 
	 * @param list
	 *            文件绝对路径集合
	 * @param zippath
	 *            ZIP包绝对路径
	 */
	public static void ZipMultiFile(List<String> list, String zippath) {
		try {
			File file = null;
			InputStream input = null;
			// 压缩后的ZIP包
			File zipFile = new File(zippath);
			ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFile));
			for (String filePath : list) {
				file = new File(filePath);
				input = new FileInputStream(file);
				zipOut.putNextEntry(new ZipEntry(file.getName()));
				int tmp = 0;
				while ((tmp = input.read()) != -1) {
					zipOut.write(tmp);
				}
				input.close();
				file.deleteOnExit();
			}
			zipOut.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 压缩单个文件
	 * 
	 * @param filepath
	 *            文件绝对路径
	 * @param zippath
	 *            生成zip包绝对路径
	 */
	public static void ZipFile(String filepath, String zippath) {
		try {
			File file = new File(filepath);
			File zipFile = new File(zippath);
			InputStream input = new FileInputStream(file);
			ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFile));
			zipOut.putNextEntry(new ZipEntry(file.getName()));
			int tmp = 0;
			while ((tmp = input.read()) != -1) {
				zipOut.write(tmp);
			}
			input.close();
			zipOut.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
