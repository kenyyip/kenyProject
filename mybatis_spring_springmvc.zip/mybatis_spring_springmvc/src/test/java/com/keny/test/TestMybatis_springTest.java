package com.keny.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.keny.model.Dossiers;
import com.keny.service.DossiersService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath*:spring.xml","classpath*:spring-mybatis.xml"})
public class TestMybatis_springTest {
	
	@Autowired
	private DossiersService ds;

	@Test
	public void test1(){
		Dossiers item = ds.selectById("21b9f645-4c92-46ed-85b3-eed8bf72cd1e");
		System.out.println(item.toString());
	}
	
}
