package com.keny.test;

import java.util.UUID;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.keny.mapper.DossiersMapper;
import com.keny.mapper.UserMapper;
import com.keny.model.Dossiers;
import com.keny.model.User;
import com.keny.utils.CipherUtil;

public class TestMybatis {
	
	private ApplicationContext ac;
	private DossiersMapper dossiersMapper;
	private UserMapper userMapper;
	
	
	@Before
	public void before(){
		ac = new ClassPathXmlApplicationContext(new String[]{"spring.xml","spring-mybatis.xml"});
		userMapper = (UserMapper)ac.getBean("userMapper");
	}
	
	@Test
	public void addUserByIdTest(){
		User user = new User();
		user.setId(UUID.randomUUID().toString());
		user.setUsername("test");
		user.setPassword(CipherUtil.generatePassword("123456"+user.getUsername()));
		int i = userMapper.insertSelective(user);
		System.out.println(i);
	}
	
	@Test
	public void loginByUserNameTest(){
		User item = userMapper.selectByUserName("admin");
		System.out.println(item.toString());
	}

	@Test
	public void findByIdTest(){
		Dossiers item = dossiersMapper.selectByPrimaryKey("21b9f645-4c92-46ed-85b3-eed8bf72cd1e");
		System.out.println(item.toString());
	}
	
	@Test
	public void addTest(){
		Dossiers record = new Dossiers();
		record.setId(UUID.randomUUID().toString());
		record.setName("叶坤");
		record.setSex(0);
		int result = dossiersMapper.insertSelective(record);
		System.out.println(result);
	}
	
	@After
	public void after(){
		
	}
	
}
