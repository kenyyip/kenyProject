package com.keny.test;

import java.io.File;

public class Test1 {
	public static void main(String[] args) {
		//String url = Thread.currentThread().getContextClassLoader().getResource("/").getPath();
		System.out.println(System.getProperty("java.class.path"));
		//String url = Test1.class.getResource("/").toString();
		//System.out.println(url);
		String path = "D:/opt/upay3/data/";
		File file = new File(path);
		System.out.println(file.mkdirs());
		File[] tempList = file.listFiles();
		System.out.println("该目录下对象个数：" + tempList.length);
		for (int i = 0; i < tempList.length; i++) {
			if (tempList[i].isFile()) {
				System.out.println("文     件：" + tempList[i]);
			}
			if (tempList[i].isDirectory()) {
				System.out.println("文件夹：" + tempList[i]);
			}
		}
	}
}