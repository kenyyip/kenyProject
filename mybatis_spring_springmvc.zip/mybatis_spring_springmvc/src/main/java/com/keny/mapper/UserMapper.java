package com.keny.mapper;

import java.io.Serializable;

import com.keny.model.User;

public interface UserMapper extends BaseMapper<User, Serializable> {

	User selectByUserName(String userName);
}