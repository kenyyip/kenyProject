package com.keny.mapper;

import java.io.Serializable;

import com.keny.model.Dossiers;

public interface DossiersMapper extends BaseMapper<Dossiers, Serializable> {
   
}