package com.keny.service;

import java.io.Serializable;

import com.keny.model.Dossiers;

public interface DossiersService extends BaseService<Dossiers, Serializable> {

}
