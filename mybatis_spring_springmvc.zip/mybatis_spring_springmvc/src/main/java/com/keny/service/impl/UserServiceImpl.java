package com.keny.service.impl;

import javax.annotation.Resource;

import com.keny.mapper.UserMapper;
import com.keny.model.User;
import com.keny.service.UserService;
import com.keny.utils.CipherUtil;

public class UserServiceImpl extends BaseServiceImpl<User> implements UserService {

	@Resource
	private UserMapper userMapper;
	
	@Override
	public User getUserByUserName(String userName,String password) {
		password = CipherUtil.generatePassword(password);
		User user = userMapper.selectByUserName(userName);
		if(null == user)
			return null;
		boolean bool = user.getPassword().equals(password);
		if(bool)
			user.setPassword("");
		return user;
			
	}

}
