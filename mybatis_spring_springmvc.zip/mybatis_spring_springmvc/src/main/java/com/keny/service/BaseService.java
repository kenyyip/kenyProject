package com.keny.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface BaseService<T, PK extends Serializable> {

	/**
	 * 根据主键删除
	 * 
	 * @param id
	 * @return 删除个数
	 * @throws DataAccessException
	 */
	int deleteById(PK id);

	/**
	 * 插入，空属性也会插入
	 * 
	 * @param record
	 * @return 插入个数
	 * @throws DataAccessException
	 */
	int add(T record);

	/**
	 * 插入，空属性不会插入
	 * 
	 * @param record
	 * @return
	 * @throws DataAccessException
	 */
	int addSelective(T record);

	/**
	 * 根据主键查询
	 * 
	 * @param id
	 * @return pojo对象
	 * @throws DataAccessException
	 */
	T selectById(PK id);

	/**
	 * 根据主键修改，空值条件不会修改成null
	 * 
	 * @param record
	 * @return
	 * @throws DataAccessException
	 */
	int updateSelective(T record);

	/**
	 * 根据主键修改，空值条件会修改成null
	 * 
	 * @param record
	 * @return
	 * @throws DataAccessException
	 */
	int update(T record);

	/**
	 * 根据查询条件分页查询
	 * 
	 * @param map
	 * @return pojo对象集合
	 * @throws DataAccessException
	 */
	public List<T> selectListByPage(Map<String, String> map);
}
