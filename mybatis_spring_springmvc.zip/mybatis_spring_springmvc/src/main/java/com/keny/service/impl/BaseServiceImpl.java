package com.keny.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.keny.service.BaseService;

public abstract class BaseServiceImpl<T> implements BaseService<T, Serializable> {

	@Override
	public int deleteById(Serializable id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int add(T record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addSelective(T record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public T selectById(Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateSelective(T record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(T record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<T> selectListByPage(Map<String, String> map) {
		// TODO Auto-generated method stub
		return null;
	}

}
