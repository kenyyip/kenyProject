package com.keny.service;

import java.io.Serializable;

import com.keny.model.User;

public interface UserService extends BaseService<User, Serializable> {

	public User getUserByUserName(String userName,String password);
	
}
