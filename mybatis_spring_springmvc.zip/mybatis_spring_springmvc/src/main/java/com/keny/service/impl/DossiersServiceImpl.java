package com.keny.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.keny.mapper.DossiersMapper;
import com.keny.model.Dossiers;
import com.keny.service.DossiersService;

@Service("dossiersService")
public class DossiersServiceImpl implements DossiersService {

	@Autowired
	private DossiersMapper dossiersMapper;

	@Override
	public int deleteById(Serializable id) {
		return dossiersMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int add(Dossiers record) {
		return dossiersMapper.insert(record);
	}

	@Override
	public int addSelective(Dossiers record) {
		return dossiersMapper.insertSelective(record);
	}

	@Override
	public Dossiers selectById(Serializable id) {
		return dossiersMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateSelective(Dossiers record) {
		return dossiersMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int update(Dossiers record) {
		return dossiersMapper.updateByPrimaryKey(record);
	}

	@Override
	public List<Dossiers> selectListByPage(Map<String, String> map) {
		return dossiersMapper.selectListByPage(map);
	}

}
