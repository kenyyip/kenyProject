package com.keny.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.keny.model.User;
import com.keny.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping("/add")
	public String add(User user){
		if(StringUtils.isEmpty(user))
			return null;
		int i = userService.addSelective(user);
		return null;
		
	}
}
