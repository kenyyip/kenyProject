package com.keny.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.keny.model.User;
import com.keny.service.UserService;

@Controller
@RequestMapping("/main")
public class CommonController {

	@Autowired
	private UserService userService;
	
	@RequestMapping("/login")
	public String login(Model model,String userName,String password){
		if(StringUtils.isEmpty(userName) || StringUtils.isEmpty(password))
			return null;
		User user = userService.getUserByUserName(userName,password);
		model.addAttribute("user", user);
		return null;
		
	}
}
