package com.keny.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.keny.model.Dossiers;
import com.keny.service.DossiersService;

@Controller
@RequestMapping("/dossiersController")
public class DossiersController {
	
	@Autowired
	private DossiersService dossiersService;

	/**
	 * http://localhost:8080/mybatis_spring_springmvc/dossiersController/showDossiers/1.do
	 * @param id
	 * @param request
	 * @return
	 */
	@RequestMapping("/showDossiers/{id}")
	public String showDossiers(@PathVariable Long id,HttpServletRequest request){
		Dossiers obj = dossiersService.selectById(id);
		System.out.println("名称："+obj.getName());
		request.setAttribute("o", obj);
		return "show";
	}
	
}
