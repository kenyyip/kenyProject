# Host: localhost  (Version: 5.5.47)
# Date: 2016-03-20 20:14:51
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES gb2312 */;

#
# Structure for table "t_dossiers"
#

DROP TABLE IF EXISTS `t_dossiers`;
CREATE TABLE `t_dossiers` (
  `id` varchar(36) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `sex` int(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `state` int(1) NOT NULL DEFAULT '0',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "t_dossiers"
#

INSERT INTO `t_dossiers` VALUES ('21b9f645-4c92-46ed-85b3-eed8bf72cd1e','叶坤',0,NULL,NULL,NULL,0,'2016-03-20 19:46:39',NULL);

#
# Structure for table "t_resources"
#

DROP TABLE IF EXISTS `t_resources`;
CREATE TABLE `t_resources` (
  `id` varchar(36) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '资源名称',
  `description` varchar(255) DEFAULT NULL COMMENT '资源描述',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源表';

#
# Data for table "t_resources"
#


#
# Structure for table "t_role"
#

DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role` (
  `id` varchar(36) NOT NULL DEFAULT '' COMMENT '角色ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '角色名称',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '角色标识',
  `description` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色权限表';

#
# Data for table "t_role"
#


#
# Structure for table "t_role_resources"
#

DROP TABLE IF EXISTS `t_role_resources`;
CREATE TABLE `t_role_resources` (
  `id` varchar(36) NOT NULL DEFAULT '',
  `rid` varchar(36) NOT NULL DEFAULT '' COMMENT '角色ID',
  `resid` varchar(36) NOT NULL DEFAULT '' COMMENT '资源ID',
  PRIMARY KEY (`id`),
  KEY `rid` (`rid`),
  KEY `resid` (`resid`),
  CONSTRAINT `t_role_resources_ibfk_1` FOREIGN KEY (`rid`) REFERENCES `t_role` (`Id`),
  CONSTRAINT `t_role_resources_ibfk_2` FOREIGN KEY (`resid`) REFERENCES `t_resources` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色资源关系表';

#
# Data for table "t_role_resources"
#


#
# Structure for table "t_user"
#

DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` varchar(36) NOT NULL DEFAULT '',
  `userName` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名，唯一性',
  `password` varchar(16) NOT NULL DEFAULT '' COMMENT '用户密码(加盐MD5)',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '用户状态 0：未激活；1：已激活；2：冻结；3：无效',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userName` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表';

#
# Data for table "t_user"
#


#
# Structure for table "t_user_role"
#

DROP TABLE IF EXISTS `t_user_role`;
CREATE TABLE `t_user_role` (
  `id` varchar(36) NOT NULL DEFAULT '',
  `uid` varchar(36) NOT NULL DEFAULT '' COMMENT '用户ID',
  `rid` varchar(36) NOT NULL DEFAULT '' COMMENT '角色ID',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `rid` (`rid`),
  CONSTRAINT `t_user_role_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `t_user` (`Id`),
  CONSTRAINT `t_user_role_ibfk_2` FOREIGN KEY (`rid`) REFERENCES `t_role` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关系表';

#
# Data for table "t_user_role"
#

